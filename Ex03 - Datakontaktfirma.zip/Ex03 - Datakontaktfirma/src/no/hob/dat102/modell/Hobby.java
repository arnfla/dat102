package no.hob.dat102.modell;

public class Hobby {

}
